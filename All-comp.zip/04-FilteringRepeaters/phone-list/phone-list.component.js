angular.module('phoneList').component('phonesList', {
	template : '<div class="container-fluid">'+
  '<div class="row">'+
    '<div class="col-md-2">Search: <input ng-model="$ctrl.query" /></div>'+
    '<div class="col-md-10">'+
      

      '<ul class="phones">'+
        '<li ng-repeat="phone in $ctrl.phones | filter:$ctrl.query">'+
          '<span>{{phone.name}}</span>'+
          '<p>{{phone.snippet}}</p>'+
        '</li>'+
      '</ul>'+

    '</div>'+
  '</div>'+
'</div>',
	/* templateUrl: 'phone-list/phone-list-template.html',*/
	controller: function PhoneListController(){
		this.phones=[
			{
				name: 'One plus 3T',
				snippet: 'Little older yet Swaggy!'
			},
			{
				name: 'One Plus 5T',
				snippet: 'Trending now !!'
			},
			{
				name: 'Vivo V7',
				snippet: 'For better Selfie!'
			}
		];
	}	

});