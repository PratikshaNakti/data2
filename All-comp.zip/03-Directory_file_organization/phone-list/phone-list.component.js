angular.module('phoneList').component('phonesList', {
	 templateUrl: 'phone-list/phone-list-template.html',
	controller: function PhoneListController(){
		this.phones=[
			{
				name: 'One plus 3T',
				snippet: 'Little older yet Swaggy!'
			},
			{
				name: 'One Plus 5T',
				snippet: 'Trending now !!'
			},
			{
				name: 'Vivo V7',
				snippet: 'For better Selfie!'
			}
		];
	}	

});