angular.module('phonecatApp').component('phoneList', {
	template: 
		'<ul>'+
		'<li ng-repeat="phone in $ctrl.phones">'+
		'<span>{{phone.name}}</span>'+
		'<p>{{phone.snippet}}</p>'+
		'</li>'+
		'</ul>',
	controller: function PhoneListController(){
		this.phones=[
			{
				name: 'One plus 3T',
				snippet: 'Little older yet Swaggy!'
			},
			{
				name: 'One Plus 5T',
				snippet: 'Trending now !!'
			},
			{
				name: 'Vivo V7',
				snippet: 'For better Selfie!'
			}
		];
	}	

});