// Define the `phonecatApp` module
angular.module('phonecatApp',[
	'ngRoute',
	'phoneDetail',
	'phoneList'
]);
