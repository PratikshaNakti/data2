angular.module('phoneList').component('phonesList', {
	/*template : '<div class="container-fluid">'+
  '<div class="row">'+
    '<div class="col-md-2">Search: <input ng-model="$ctrl.query" /></div>'+
    '<p>Order by: '+
    '<select ng-model="$ctrl.orderProp">'+ 
    '<option value="name"> Alphabetical</option>'+ 
    '<option value="age"> Age</option>'+ 
    '</select>'+
    '</p>'+
    '<div class="col-md-10">'+
      

      '<ul class="phones">'+
        '<li ng-repeat="phone in $ctrl.phones | filter:$ctrl.query | orderBy:$ctrl.orderProp" class="thumbnail">'+
          '<a href="#" class="thumb"> <img ng-src="{{phone.imageUrl}}" alt="{{phone.name}}" /></a>'+
          '<div class="detail"><a href="#"> {{phone.name}} </a>'+
          '<p>{{phone.snippet}}</p></div>'+
        '</li>'+
      '</ul>'+

    '</div>'+
  '</div>'+
'</div>',*/
	 templateUrl: 'phone-list/phone-list-template.html',
	/*controller: function PhoneListController(){
		this.phones=[
			{
				name: 'Vivo V7',
				snippet: 'For better Selfie!',
				age: 1,
				id: 'vivo_1',
				imageUrl: 'img/phones/vivo_1.jpg'
			},
			{
				name: 'One Plus 5T',
				snippet: 'Trending now !!',
				age: 2,
				id: 'onePlus5T',
				imageUrl: 'img/phones/onePlus5T.jpg'
			},
			{				
				name: 'One plus 3T',
				snippet: 'Little older yet Swaggy!',
				age: 4,
				id: 'onePlus3T',
				imageUrl: 'img/phones/onePlus3T.jpg'
			},
			{				
				name: 'Mi Note 4',
				snippet: 'Long lasting Batter',
				age: 3,
				id: 'MiNote4',
				imageUrl: 'img/phones/MiNote4.jpg'
			}
		];
		this.orderProp='age';
	}	
*/
	
	  controller: function PhoneListController($http) {
      var self = this;
      self.orderProp = 'age';

     $http.get('phones/phones.json').then(function(response) {
        self.phones = response.data;
      });
     }

});