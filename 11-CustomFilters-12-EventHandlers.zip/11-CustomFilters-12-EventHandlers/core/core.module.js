/**
 * Created by pnakti on 4/30/2018.
 */
angular.module("core", []);