/**
 * Created by pnakti on 4/30/2018.
 */
angular.module('core').filter('checkmark', function () {
    return function (input) {
        return input ? '\u2713' : '\u2718';
    };
});