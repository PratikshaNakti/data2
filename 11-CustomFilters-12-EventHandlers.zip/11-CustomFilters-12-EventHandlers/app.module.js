'use strict';

// Define the `phonecatApp` module
angular.module('phonecatApp', [
    'ngRoute',
    'core',
    'phoneDetail',
    'phoneList'
]);
