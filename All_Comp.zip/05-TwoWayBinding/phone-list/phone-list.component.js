angular.module('phoneList').component('phonesList', {
	template : '<div class="container-fluid">'+
  '<div class="row">'+
    '<div class="col-md-2">Search: <input ng-model="$ctrl.query" /></div>'+
    '<p>Order by: '+
    '<select ng-model="$ctrl.orderProp">'+ 
    '<option value="name"> Alphabetical</option>'+ 
    '<option value="age"> Age</option>'+ 
    '</select>'+
    '</p>'+
    '<div class="col-md-10">'+
      

      '<ul class="phones">'+
        '<li ng-repeat="phone in $ctrl.phones | filter:$ctrl.query | orderBy:$ctrl.orderProp">'+
          '<span>{{phone.name}}</span>'+
          '<p>{{phone.snippet}}</p>'+
        '</li>'+
      '</ul>'+

    '</div>'+
  '</div>'+
'</div>',
	/* templateUrl: 'phone-list/phone-list-template.html',*/
	controller: function PhoneListController(){
		this.phones=[
			{
				name: 'Vivo V7',
				snippet: 'For better Selfie!',
				age: 1
			},
			{
				name: 'One Plus 5T',
				snippet: 'Trending now !!',
				age: 2
			},
			{				
				name: 'One plus 3T',
				snippet: 'Little older yet Swaggy!',
				age: 4
			},
			{				
				name: 'Mi Note 4',
				snippet: 'Long lasting Batter',
				age: 3
			}
		];
		this.orderProp='age';
	}	

});