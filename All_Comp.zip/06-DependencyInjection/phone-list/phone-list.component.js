angular.module('phoneList').component('phonesList', {
	template : '<div class="container-fluid">'+
  '<div class="row">'+
    '<div class="col-md-2">Search: <input ng-model="$ctrl.query" /></div>'+
    '<p>Order by: '+
    '<select ng-model="$ctrl.orderProp">'+ 
    '<option value="name"> Alphabetical</option>'+ 
    '<option value="age"> Age</option>'+ 
    '</select>'+
    '</p>'+
    '<div class="col-md-10">'+
      

      '<ul class="phones">'+
        '<li ng-repeat="phone in $ctrl.phones | filter:$ctrl.query | orderBy:$ctrl.orderProp">'+
          '<span>{{phone.name}}</span>'+
          '<p>{{phone.snippet}}</p>'+
        '</li>'+
      '</ul>'+

    '</div>'+
  '</div>'+
'</div>',
	/* templateUrl: 'phone-list/phone-list-template.html',*/
	controller: ['$http',
      function PhoneListController($http) {
        var self = this;
        self.orderProp = 'age';

        $http.get('phones/phones.json').then(function(response) {
          self.phones = response.data;
        });
      }
    ]
	

});