import React from 'react'
import App from './App'
import {BrowserRouter} from 'react-router-dom'
class Main extends React.Component {
    render() {
        return (
            <div>
                <BrowserRouter>
                <App/>
                </BrowserRouter>
            </div>
        )
    }
}
export default Main;