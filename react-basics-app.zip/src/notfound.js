import React from 'react'
class NotFound extends React.Component {
    
    render() {
        document.title = '404'
        return (
            <div>
                <h1>Page Not Found</h1>
            </div>
        )
    }
}
export default NotFound;