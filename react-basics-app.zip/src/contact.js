import React from 'react'
class Contact extends React.Component {
    render() {
        document.title = 'Contact'
        const query = new URLSearchParams(this.props.location.search);
        const phone = query.get('ph');
        const name = query.get('name');
        return (
            <div>
                <h1>Contact Component</h1>
                {phone}<br/>
                {name}
            </div>
        )
    }
}
export default Contact;