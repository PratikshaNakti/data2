import React from 'react'
class Login extends React.Component {
    validate = (evt)=> {
        evt.preventDefault();
        if (this.refs.username.value === 'nagaraju' && this.refs.password.value==='123'){
            this.props.history.push('/home')
        }
    }
    render() {
        return(
            <div>
                <form>
                    <input type="text" ref="username" placeholder="username here"/>
                    <input type="password" ref="password" placeholder="password here"/>
                    <button type="submit" onClick={this.validate}>Login</button>
                </form>
            </div>
        )
    }
}
export default Login