import React, { Component } from 'react';
import logo from './logo.svg';
import './App.css';
import ProductList from './product-list'
import {Link, Route, Switch} from 'react-router-dom'
import Home from './home'
import About from './about'
import Contact from './contact'
import NotFound from './notfound'
import Login from './login'
// class component
class App extends Component {
  state = {
    users: []
  }
  addUser = (evt)=> {
    evt.preventDefault();
    var userlist = this.state.users;
    userlist.push(this.refs.user.value)
    this.setState({users: userlist})
    this.refs.user.value = '';
  }
  removeUser = (indx)=> {
    var userlist = this.state.users;
    userlist.splice(indx, 1);
    this.setState({users: userlist})
  }
  render() {
    
    return (
      <div class="part1">
        <header class="header1">
        <ul>
          
        </ul>
        </header>
        <section class="content1">
        <section class="content_l">
        
        
       
        </section>
        <section class="content_r">
        <Route exact path="/" component={Login}/>
        <Route path="/home" component={Home}/>
        <Route path="/products" component={ProductList}/>
        <Route path="/logout" component={Login}/>
        </section>
        </section>
        <footer class="footer"></footer>
      </div>
    );
  }
}

export default App;
