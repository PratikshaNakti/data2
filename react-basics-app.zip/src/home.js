import React from 'react'
import {Link} from 'react-router-dom'
class Home extends React.Component {
    
    render() {
        document.title = 'Home'
        return (
            <div>
                <Link to="/products">Products</Link>
                <Link to="/logout">Logout</Link>
            </div>
        )
    }
}
export default Home;