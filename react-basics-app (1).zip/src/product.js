import React from 'react'

class Product extends React.Component {
    handleClicks = ()=> {
        this.props.countClicks(this.props.id)
    }
    
    render() {
        return (
            <div class="main">
                <div class="m_l">
                    <img src="images/iphone_6s.jpg" alt="iphone 6s"/>
                </div>
                <div class="m_r" >
                    <a onClick={this.handleClicks} href="#" ><p>Model: {this.props.model}</p></a>
                    <p>Price:  {this.props.price}</p>
                    <p>{this.props.votes}</p>
                </div>
            </div>
        )
    }
}
export default Product;