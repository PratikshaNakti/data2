import React from 'react'
import Product from './product'
class ProductList extends React.Component {
    state = {
        products : [
            {model: 'iphone 6s', votes: 1, price: 45000, id: 1, url: "images/iphone_6s.jpg"},
            {model: 'samsung s9', votes: 1, price: 25000, id: 2, url: "images/samsung_s9.jpg"},
            {model: 'micromax moto g', votes: 1, price: 35000, id: 3, url: "images/micromax.jpg"},
        ]
    }
    
    countClicksOnProduct = (pid)=> {
        console.log(pid + " was clicked");
        const productlist = this.state.products;
        productlist.map((product) => {
            if (product.id == pid) {
                product.votes = product.votes + 1;
            }
        })
        this.setState({products: productlist})
    }
    sortProducts(a, b) {
        return a.model >= b.model
    }
    render() {
        const sortedproducts = this.state.products.sort(this.sortProducts);
        const product = sortedproducts.map((pro) => (
            <Product model = {pro.model}
                     price = {pro.price}
                     id = {pro.id}
                     imageUrl = {pro.url}
                     countClicks = {this.countClicksOnProduct}
                     votes = {pro.votes}
            />
        ));
        return (
            <div>
                {product}
                
            </div>
        )
    }
}
export default ProductList