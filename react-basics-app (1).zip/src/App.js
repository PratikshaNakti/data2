import React, { Component } from 'react';
import logo from './logo.svg';
import './App.css';
import ProductList from './product-list'

// class component
class App extends Component {
  render() {
    return (
      <div>
        {/* <Hello city="Hyderabad"/> */}
        <ProductList/>
      </div>
    );
  }
}

// functional component 
/*const Hello = (props) => {
  return (
 <div>
   <h1>Hello {props.city}</h1>
   
 </div>
)
}*/
export default App;
